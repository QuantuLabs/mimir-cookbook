# Mimir beta quickstart

Import only the explicit beta subpath:

```ts
import {
  createMimir8004IdentityAdapter,
  createMimirBetaClient,
  createMimirBetaStageReceipt,
  MIMIR_BETA_AGENT_URI_MAX_UTF8_BYTES,
  assertMimirBetaFusedSignedTransaction,
  observeMimirBetaReceipt,
  parseMimirBetaIntegerQuantityX64,
  verifyMimirBetaFinalizedReceiptEvidence,
  type MimirBetaPreparedStep,
  type MimirBetaPlanningRpc,
  type MimirBetaPoolDiscovery,
  type MimirBetaStageReceipt,
} from "@quantulabs/mimir-sdk/beta";
```

## 1. Inject every environment dependency

Supply the cluster, program addresses, physical MPL Core collection, canonical
collection pointer, finalized RPC transport, and pool discovery implementation.
The SDK has no RPC URL, secret, signer, send, lookup-table, or fallback
default, and never splits a transaction.

```ts
const identity = createMimir8004IdentityAdapter(deployment);
const client = createMimirBetaClient({
  deployment,                // localnet, devnet, or mainnet-beta; all IDs explicit
  rpc: finalizedRpc as MimirBetaPlanningRpc,
  discovery: poolDiscovery as MimirBetaPoolDiscovery,
  identity,
});
```

Before the first preparation, the client proves the finalized local Transaction
v1 feature account once and caches that promise. Missing, inactive, malformed,
wrong-owner, or stale evidence blocks before blockhash, review, signing, or send.

`listPoolSources()` describes the injected families. Search and bound the
selection before preparation:

```ts
const sources = await client.listPoolSources();
const result = await client.searchSpotPools({
  baseMint,
  quoteMint,
  query: "",
  maxPools: 5,
});
const selected = result.recommendedPools.slice(0, 3);
```

Search and revalidation fail closed on empty, stale, ineligible, duplicated, or
role-confusable pools. A simple feed accepts 1..5 selected pools.

The public simple and composite creation facade requires a canonical, non-empty,
trim-stable agent URI of at most
`MIMIR_BETA_AGENT_URI_MAX_UTF8_BYTES` (54) UTF-8 bytes. This fused-creation
limit ensures packet parity across Classic/simple N=1..5 and Composite N=2..5 transactions; it
is a Solana transaction-packet bound, not an 8004 reputation or economics
policy. The non-sensitive example URI below is within the bound.

## 2. Prepare and review a simple feed

```ts
import { generateKeyPairSigner, type KeyPairSigner } from "@solana/kit";

let freshAssetSigner: KeyPairSigner | null = await generateKeyPairSigner();
const freshCoreAssetSignerAddress = freshAssetSigner.address;

let prepared = await client.prepareSimpleFeed({
  authority,
  baseMint,
  quoteMint,
  pools: selected,
  identity: {
    asset: freshCoreAssetSignerAddress,
    agentUri: "https://example.com/mimir/feed.json",
  },
  creatorCollateralTokenAccount,
  policy: {
    profile: 0,
    riskTier: 1,
    priceExponent: -8,
    maxDispersionBps: 100,
    maxSourceActivityAgeSlots: 150,
    minCoverageRatioBps: 8_000,
    maxConfidenceBps: 100,
    maxSnapshotAgeSlots: 150,
    anchorPolicyHash,
    nativeExceptionHash,
  },
});

if (prepared.next) {
  showReview(prepared.next.review);
  // The application-owned flow below signs and persists this exact review.
}
```

Each call prepares only the next reviewable step. Classic creation centres on
tag-80 `classic:activate`, preceded by packed preparation steps and followed by
`classic:ready` only when the plan does not fit one transaction; each step is an
indivisible transaction. On-demand consumer refresh is outside the Create Feed
plan.

For a fresh AMM v4 or PumpSwap source, an omitted `temporalMode` resolves to
`"current-point"` (current pool price, limited trading capacity; no TWAP
history) and `prepared.temporalMode` reports it. Pass `"sampled-interval"`
explicitly to opt into the sampled profile. When resuming with receipts, pass
the bound `prepared.temporalMode`; an omitted mode on a point-capable resume is
refused. An explicit `"current-point"` when no selected source supports it is
refused with `INVALID_ARGUMENT`. Inline composite `createClassic` components
resolve the same way.

An omitted or `null` recipe resolves to the economic spot recipe for every
family that admits it, including a standalone Raydium CPMM pool (mode 0, E4)
and a CPMM composite component (its mode-6 spot projection). AMM v4 and
PumpSwap keep their `temporalMode` resolution above. Every other recipe is an
explicit opt-in with its own preflights: `"native-bounded"`,
`"dual-native-point"`, `"current-point"` or a quiet/sampled interval arm (a
resume must repeat the same choice). Native history that is not ready throws
`CLASSIC_NATIVE_NOT_READY` (`MimirClassicNativeNotReadyError`) before any
collateral funding facts or instruction. Quiet interval suits pools that stay
unchanged for 120 s at a time. A SOL converter feed stays native-only and must
pass `"native-bounded"` explicitly.

Confidence presets (`maxConfidenceBps`, chosen by the caller, never widened by
the SDK): 250 bps for volatile assets, 100 bps for liquid assets whose evidence
supports it, 500 bps or 1000 bps as explicit wider options with lower exposure.
`maxDispersionBps` is a separate choice for a multi-venue spot set.

When a CPMM quiet feed's publish refresh is refused as not Fresh, prime it:
`client.prepareClassicQuietPrime(...)` returns an exact sample-only refresh;
after it confirms, `client.verifyClassicQuietPrime(prime, slot)` re-reads the
module and returns `anchored` (with `waitSecs` until A + 120 s),
`not-anchored` or `conditioned`. Only `anchored` justifies waiting and then
preparing a new refresh+publish. `client.inspectNativeReadiness({ feedId })`
reports each native row as `ready`, `history-rebuilding` (DLMM `aboutSecs`
estimate) or `waiting-for-activity`; a prime does not help native rows.

A SOL-quoted feed embeds an existing SOL/USDC classic feed as its converter
(`solConversionSourceConfig`). Every converter leg must be an admitted native
source with ready native history and a verified successful pool trade within
the converter's source-activity age; otherwise preparation throws
`CONVERTER_INELIGIBLE` (`MimirBetaConverterIneligibleError`, naming the leg)
before any collateral funding facts or payable review. The planning RPC must
provide `getSignaturesForAddress` and `getTransaction` for this check. Use
`client.inspectConverterEligibility({ feedId })` and
`rankMimirBetaConverterEligibility` to offer only eligible converters.

## 3. Co-sign the exact fused terminal step and write ahead

The identity/activation core of `classic:activate` is 8004 register with the
exact reviewed agent URI and ATOM disabled, locked collection pointer, then
Mimir tag 80. The core of `composite:activate` is those identity instructions,
the immutable display-name metadata write, then Mimir tag 81. The core is not
the whole transaction: a fused step may also carry proposal/source appends,
missing classic component identities, execution, initializer or publication.
The outer instructions and required signers come from the exact reviewed step.
The example below applies only to an activation step whose required signers
are exactly the authority wallet and the fresh Core asset; wallet-only
continuation steps carry no asset signer, and a composite step that also
creates missing components requires each of their fresh asset signers. Use an
injected non-modifying `TransactionPartialSigner` for the wallet. Every
required signer signs the same decoded reviewed transaction; none may replace
or augment its message. The SDK does
not perform any of these signing, persistence, sending, or lifecycle actions.

```ts
import {
  assertIsFullySignedTransaction,
  assertIsTransactionWithinSizeLimit,
  getPublicKeyFromAddress,
  getSignatureFromTransaction,
  getTransactionDecoder,
  getTransactionEncoder,
  signatureBytes,
  verifySignature,
  type Address,
  type Blockhash,
  type KeyPairSigner,
  type ReadonlyUint8Array,
  type SignatureDictionary,
  type Slot,
  type TransactionPartialSigner,
  type TransactionWithBlockhashLifetime,
} from "@solana/kit";

type AuthorityWallet = Pick<TransactionPartialSigner, "address" | "signTransactions">;

const sameBytes = (left: ArrayLike<number>, right: ArrayLike<number>) => {
  if (left.length !== right.length) return false;
  for (let index = 0; index < left.length; index += 1) {
    if (left[index] !== right[index]) return false;
  }
  return true;
};
const sameAddressSet = (left: readonly string[], right: readonly string[]) =>
  left.length === right.length && new Set(left).size === left.length &&
  [...left].sort().every((value, index) => value === [...right].sort()[index]);
const assertOneSignature = (dictionary: SignatureDictionary, signer: Address) => {
  const keys = Object.keys(dictionary);
  const signature = dictionary[signer];
  if (keys.length !== 1 || keys[0] !== signer ||
      !(signature instanceof Uint8Array) || signature.length !== 64) {
    throw new Error("missing, extra, or mismatched signer response");
  }
};

async function signPersistAndSendIdentity(args: {
  preparedStep: MimirBetaPreparedStep;
  authorityWallet: AuthorityWallet;
  assetSigner: KeyPairSigner;
  attempt: 1 | 2;
  retryOfSignature: string | null;
  persistReceipt: (receipt: MimirBetaStageReceipt) => Promise<void>;
  sendRawTransaction: (wire: ReadonlyUint8Array) => Promise<string>;
}) {
  const { preparedStep, authorityWallet, assetSigner } = args;
  const reviewed = preparedStep.transaction;
  if ((preparedStep.step.stepId !== "classic:activate" &&
       preparedStep.step.stepId !== "composite:activate") ||
      preparedStep.review.authority !== authorityWallet.address ||
      preparedStep.review.identityAsset !== assetSigner.address ||
      reviewed.feePayer !== authorityWallet.address) {
    throw new Error("identity review/signer binding mismatch");
  }

  const required = [...reviewed.requiredSigners];
  const expected = [authorityWallet.address, assetSigner.address];
  if (!sameAddressSet(required, expected) ||
      !sameAddressSet(preparedStep.step.requiredSigners, required) ||
      !sameAddressSet(preparedStep.review.requiredSigners, required)) {
    throw new Error("identity required signer set mismatch");
  }

  const decoder = getTransactionDecoder();
  const decoded = decoder.decode(reviewed.serializedTransaction);
  if (!sameAddressSet(Object.keys(decoded.signatures), required) ||
      Object.values(decoded.signatures).some((value) => value !== null) ||
      !sameBytes(decoded.messageBytes, reviewed.serializedMessage)) {
    throw new Error("reviewed bytes or zero-signature map mismatch");
  }
  const immutableMessage = decoded.messageBytes.slice();
  const signable = {
    ...decoded,
    messageBytes: Uint8Array.from(decoded.messageBytes) as unknown as typeof decoded.messageBytes,
    signatures: { ...decoded.signatures },
    lifetimeConstraint: {
      blockhash: reviewed.recentBlockhash as Blockhash,
      lastValidBlockHeight: reviewed.lastValidBlockHeight as Slot,
    },
  } as typeof decoded & TransactionWithBlockhashLifetime;
  assertIsTransactionWithinSizeLimit(signable);

  // Never share one mutable transaction object across signer boundaries.
  const walletInput = {
    ...signable,
    messageBytes: signable.messageBytes.slice() as unknown as typeof signable.messageBytes,
    signatures: { ...signable.signatures },
    lifetimeConstraint: { ...signable.lifetimeConstraint },
  } as typeof signable;
  const assetInput = {
    ...signable,
    messageBytes: signable.messageBytes.slice() as unknown as typeof signable.messageBytes,
    signatures: { ...signable.signatures },
    lifetimeConstraint: { ...signable.lifetimeConstraint },
  } as typeof signable;

  const [walletResults, assetResults] = await Promise.all([
    authorityWallet.signTransactions([walletInput]),
    assetSigner.signTransactions([assetInput]),
  ]);
  if (walletResults.length !== 1 || assetResults.length !== 1 ||
      !sameBytes(signable.messageBytes, immutableMessage) ||
      !sameBytes(walletInput.messageBytes, immutableMessage) ||
      !sameBytes(assetInput.messageBytes, immutableMessage)) {
    throw new Error("signer changed reviewed bytes or result cardinality");
  }
  assertOneSignature(walletResults[0], authorityWallet.address);
  assertOneSignature(assetResults[0], assetSigner.address);
  const [walletKey, assetKey] = await Promise.all([
    getPublicKeyFromAddress(authorityWallet.address),
    getPublicKeyFromAddress(assetSigner.address),
  ]);
  const [walletSignatureValid, assetSignatureValid] = await Promise.all([
    verifySignature(
      walletKey,
      signatureBytes(walletResults[0][authorityWallet.address]),
      immutableMessage,
    ),
    verifySignature(
      assetKey,
      signatureBytes(assetResults[0][assetSigner.address]),
      immutableMessage,
    ),
  ]);
  if (!walletSignatureValid || !assetSignatureValid) {
    throw new Error("signature does not verify against the reviewed message");
  }

  const signatures = { ...decoded.signatures, ...walletResults[0], ...assetResults[0] };
  if (!sameAddressSet(Object.keys(signatures), required)) {
    throw new Error("merged signature map mismatch");
  }
  const signed = { ...signable, signatures };
  assertIsFullySignedTransaction(signed);
  const wire = getTransactionEncoder().encode(signed);
  if (!sameBytes(getTransactionDecoder().decode(wire).messageBytes, immutableMessage)) {
    throw new Error("encoded message changed before send");
  }
  await assertMimirBetaFusedSignedTransaction({
    preparedStep,
    signedTransaction: Uint8Array.from(wire),
    signatures: [
      { address: authorityWallet.address, signature: Uint8Array.from(walletResults[0][authorityWallet.address]) },
      { address: assetSigner.address, signature: Uint8Array.from(assetResults[0][assetSigner.address]) },
    ],
  });

  const receipt: MimirBetaStageReceipt = createMimirBetaStageReceipt({
    preparedStep,
    signature: getSignatureFromTransaction(signed),
    attempt: args.attempt,
    retryOfSignature: args.retryOfSignature,
  });
  await args.persistReceipt(receipt); // durable public write-ahead; no key material
  const sentSignature = await args.sendRawTransaction(wire); // the sole raw send
  if (sentSignature !== receipt.signature) throw new Error("transport signature mismatch");
  return receipt;
}
```

Reject before persistence and send if either required signer is missing or
extra, either signature dictionary is not keyed only by its declared signer,
either signature fails cryptographic verification against the immutable
reviewed message, the signature-map union differs from the reviewed signer set,
or any message byte changes. Give each signer an independent transaction clone;
never share a mutable message buffer across signer boundaries. Never stringify,
export, persist, log, or pass
`freshAssetSigner.keyPair` to callbacks. Retain the signer while the identity
receipt is pending (and through the single permitted retry); after a finalized
fused activation observation or an explicit terminal abandon, end the lifecycle and
drop every reference:

```ts
// Only at one of those two terminal outcomes:
freshAssetSigner = null;
```

An application cannot synchronously erase a WebCrypto private key; disposal
means making the signer unreachable. If a transient observer error is still
retryable, it is not a terminal abandon and the signer must remain live.

## 4. Reconcile a receipt before resuming

```ts
const observation = await observeMimirBetaReceipt({
  rpc: finalizedRpc,
  receipt,
});

prepared = await client.prepareSimpleFeed({
  ...sameDraftInputs,
  pools: draftPools,
  receipts: [...receipts, receipt],
  observations: [...observations, observation],
});
```

`draftPools` is the `selectedPools` of the preparation whose step produced the
first receipt; persist it with that receipt. Without receipts, a preparation
re-observes the selected pools at the current finalized slot and binds that
evidence into the draft, so the original search result rebuilds a different
draft as soon as that slot has advanced and every receipt is rejected with
`RECEIPT_MISMATCH`.

The receipt carries only the immutable public reviewed step/review lineage, not
message or transaction bytes. After a reload, the collector authenticates that
lineage and one finalized raw Transaction v1, then performs
one address-bound `getMultipleAccounts` read with `minContextSlot` equal to the
transaction slot. `verifyMimirBetaFinalizedReceiptEvidence` is the equivalent
pure verifier when those two evidence objects are already available. There is
no caller-authored `expectedWritesMatch` switch. An atomic failed attempt is
retryable once only when its review-hashed baseline still matches; the retry
retains `stepIntentHash` and `expectedWritesHash` but requires a fresh message,
review, signature, and `retryOfSignature`.

## 5. Prepare a composite feed

The legacy tag-64 constructor is intentionally unavailable from the package root because the accepted Program rejects tag 64. Standalone users should use `@quantulabs/mimir-sdk/beta` and `client.prepareCompositeFeed`, which builds permissionless tag 81.

Use the exact integer helper for user-facing positive whole quantities. It
accepts canonical decimal digits from 1 through `u64::MAX` and returns
`BigInt(value) << 64`; signs, fractions, exponent notation, leading zeroes, zero,
and overflow are rejected.

```ts
const composite = await client.prepareCompositeFeed({
  authority,
  displayName: "SOL Ecosystem Index",
  quoteMint,
  components: selectedComponents.map((component) => ({
    feedId: component.feedId,
    sourceConfig: component.sourceConfig,
    quantityX64: parseMimirBetaIntegerQuantityX64(component.quantityText),
  })),
  identity: {
    asset: freshCoreAssetSignerAddress,
    agentUri: "https://example.com/mimir/feed.json",
  },
  creatorCollateralTokenAccount,
  policy: {
    priceExponent: -8,
    maxSnapshotAgeSlots: 150,
    maxComponentSnapshotAgeSlots: 150,
    maxComponentConfidenceBps: 100,
    maxComponentDispersionBps: 100,
  },
});
```

Advanced callers may provide a raw positive `quantityX64` up to `u128::MAX`.
Composite tag-81 activation is permissionless, uses the fixed global
`compositeRefreshFeeLamports` from AdminConfig, and likewise reports `awaiting
first refresh`.

For a submitted creation stage, `observeMimirBetaConfirmedReceipt({ rpc, receipt })`
authenticates the exact submitted message, reviewed lineage, baseline and poststate
at confirmed commitment. Its `confirmed` observation is separate from finalized
reconciliation.

Use `client.prepareSimpleFeedConfirmed(input, rpc)` or
`client.prepareCompositeFeedConfirmed(input, rpc)` to prepare the next unsigned
review before finalization. Supply the durable receipts in `input.receipts` and a
trusted RPC for the same deployment that supports confirmed transaction and
account reads. This reader serves next-stage account planning; the configured
planning RPC performs exact confirmed simulation. Pool discovery must honor the
receipt context floor. The SDK re-fetches prerequisite poststate after simulation
before returning a review. Caller-authored observations cannot advance this path.
Use `observeMimirBetaReceiptChain({ rpc, receipts })` and ordinary preparation
for durable finalized completion when a later stage has updated or closed an
earlier proposal. Proposal baseline bytes are bound into the successor's
reviewed writes; an authenticated successor must prove that transition before
an earlier proposal effect can be reconciled. Singleton receipt observation
retains its original finalized expiry/retry behavior. All-confirmed preparation
remains `await-finality`.

### Several new components: the multi-transaction journey

`client.prepareCompositeFeedJourney({ input, state, preparationCommitment, reviewMode }, rpc)`
creates a composite whose missing components are new one-pool Classics. Each
missing child is its own atomic `classic:activate` (8004 register + collection
pointer + proposal + source append + tag 80, signed by the wallet and that
child's asset) with its own draft and receipts; the root is prepared afterwards
from the live, canonically verified children without any child instruction.
A child that already exists canonically is reused, never recreated or charged.

- Persist the returned `state` (public operations, identities, drafts, receipts;
  no keys or signed wires) and pass it back with each new receipt appended to
  its own operation. Pass back `next.selectedPools[0]` as that child's `pool`.
  A receipt-bound operation keeps its identity and definition.
- Funding is one aggregate `MimirBetaCollateralRequiredError` over every remaining
  tariff (`draftHash` is the journey `intentHash`; `compositeJourney` lists the
  operations and every remaining packet), so one SOL purchase covers the journey.
- `preparationCommitment: "processed"` prepares the next child provisionally once
  its predecessor has a successful processed status (`next.provisional`,
  `next.prerequisites`); every receipt must still reach finality before
  `action: "complete"`.
- `reviewMode: "child-batch"` returns every currently preparable child core
  (`childBatch`) for a wallet batch; admit the returned wires with
  `admitMimirBetaWalletSignedBatchV1` before any asset signs. A batch is not one
  approval, and later outputs may need a fresh review after earlier burns.
- Each transaction follows wallet-first signing: unsigned wire -> wallet ->
  exact rewrite/guard + wallet signature admission -> asset signs the final bytes
  -> durable receipt -> one send. The journey is not atomic across transactions.

## 6. Inspect ownership, not entitlements

```ts
const ownership = await client.inspectFeedOwnership({ feed, minContextSlot });
```

The returned relation binds the immutable Mimir feed-to-8004 asset identity and
the asset's current live MPL Core owner. Catalogue consumers must use
`ownership.displayName` only when `ownership.verificationStatus === "verified"`;
Composite names come from the immutable coherent 8004 metadata read, never an
external directory label. Mimir does not define or enforce market,
trading, fee, reputation, revenue, governance, or other economic rights for that
owner. Each consumer protocol or app must define and enforce those rights in its
own on-chain authority boundary.

## Failure boundary

Handle `MimirBetaError.code`. Configuration and state failures are explicit,
including `CREATION_CONTEXT_REQUIRED`, `RPC_CONTEXT_MISMATCH`, `POOL_STALE`,
`TRANSACTION_TOO_LARGE`, `SIMULATION_FAILED`, `CONVERTER_INELIGIBLE`,
`RECEIPT_MISMATCH`, `RECONCILIATION_CONFLICT`, and
`UNCHANGED_RETRY_EXHAUSTED`. Never fall back to a hidden endpoint, unsigned
claim, caller boolean, lookup table, v0 transport, fallback, or split after one of these errors.
