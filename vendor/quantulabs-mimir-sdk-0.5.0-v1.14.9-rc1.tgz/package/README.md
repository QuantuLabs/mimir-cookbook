# Mimir SDK

TypeScript SDK for Mimir snapshot decoding, PDA derivation, and instruction
construction.

This SDK is intentionally separate from the Pinocchio program repository.

## Beta identity facade

The browser-safe beta entry point is `@quantulabs/mimir-sdk/beta`. It exposes
one injected client with methods including `listPoolSources`,
`searchSpotPools`, `prepareSimpleFeed`, `prepareCompositeFeed`, and
`inspectFeedOwnership`. Each preparation call returns the next unsigned,
message-first Transaction v1 plus a review and proof-complete expected writes.
Every transaction compiles without lookup tables or fallback, and a packet that
does not fit is refused, never split; the SDK never sends or chooses an RPC
endpoint.

```ts
import {
  createMimir8004IdentityAdapter,
  MIMIR_BETA_MPL_CORE_PROGRAM_ID,
  MIMIR_BETA_SYSTEM_PROGRAM_ID,
} from "@quantulabs/mimir-sdk/beta";
import { address } from "@solana/kit";

const identity = createMimir8004IdentityAdapter({
  cluster: "localnet",
  mimirProgramId: address("<MIMIR_PROGRAM_ADDRESS>"),
  agentRegistryProgramId: address("<AGENT_REGISTRY_8004_ADDRESS>"),
  mplCoreProgramId: MIMIR_BETA_MPL_CORE_PROGRAM_ID,
  systemProgramId: MIMIR_BETA_SYSTEM_PROGRAM_ID,
  physicalCollection: address("<MPL_CORE_COLLECTION_ADDRESS>"),
  collectionPointer: "c1:<LOWERCASE_BASE32_POINTER>",
});
```

Every deployment value is explicit; there are no cluster or address defaults. Mimir authenticates identity and the current MPL Core owner and enforces holder fee claims and component inclusion payments. Consumer protocols enforce any additional trading, fee, revenue, governance and other economic rights at their own onchain boundary.

Create Feed is nominally one fused transaction, automatically staged when the
fused plan does not fit; composite callers may also request staged execution
explicitly (`stagedExecution: true`). Classic creation may prepend `classic:proposal-init` /
`classic:source-append:*` steps before `classic:activate` (tag 80) and append
`classic:ready` when readiness does not fuse; composite creation stages
`composite:activate` (tag 81) then `composite:execution`, or
`composite:init` + `composite:publish`. On-demand consumer refresh is a
separate lifecycle, not another creation signature.
See [`docs/BETA_QUICKSTART.md`](./docs/BETA_QUICKSTART.md) for the injected
discovery, staged receipt, finalized Transaction v1 evidence, and ownership flow. That
quickstart ships in the npm tarball and includes the application-owned identity
signing boundary: the app partially signs the exact reviewed message with a
fresh in-memory asset `CryptoKeyPair`, forwards opaque raw v1 bytes to Wallet
Standard once, verifies both signatures, and persists the public stage
receipt before one raw send. The ephemeral signer is discarded
only after finalization or explicit terminal abandon. The SDK accepts the
memory-only key only for that immediate partial-sign call; it never persists a
key, sends, or selects an RPC endpoint.

```bash
npm install
npm run check
```

## Supported identities

Mint-oracle discovery and verification support `mainnet`, `devnet`, and
`localnet`. Localnet uses the exact mainnet Mimir program, token, venue-program,
venue-config, account-layout, and admission-policy identities; devnet uses its
own explicit venue-program and quote-mint table. The beta flow is
documented in [`docs/BETA_QUICKSTART.md`](./docs/BETA_QUICKSTART.md).

## Transaction Policy

The legacy root v0 helpers compile v0 transactions with address lookup tables. The beta
path compiles Transaction v1 without lookup tables (see [`docs/BETA_QUICKSTART.md`](./docs/BETA_QUICKSTART.md)).

## Warming recovery

`getMimirWarmingRecovery(error)` returns `{ feedId, reason: "warming", refreshOnlyInstructions, remainingWarmupSeconds }` for mixed-bounded, DAMM OnlyB and CPMM quiet warming errors, and `null` for every other error (including `unavailable` and `stale`). For mixed-bounded warming `remainingWarmupSeconds` is `null`; compute it with `mimirWarmingRemainingSeconds(error, chainUnixTs)`.

## Localnet verification

Use the active `localnet:*` commands in `package.json`. Every localnet fixture
must use the exact mainnet Mimir program, token, venue-program, venue-config,
account-layout, and admission-policy identities. Localnet-only or testnet
identities are not release evidence.

## Raydium CPMM Source Graphs

`computeCpmmSourceAccountsHash`, `computeOrcaWhirlpoolSourceAccountsHash`,
`computeMeteoraDlmmSourceAccountsHash`,
`computeMeteoraDlmmRouteableSourceAccountsHash`,
`computeRaydiumClmmSourceAccountsHash`, and
`computeRaydiumClmmRouteableSourceAccountsHash` mirror the on-chain single-source
account-graph domains. The routeable Meteora helper binds lower/active/upper
`BinArray` accounts to `MIMIR_ACCOUNTS_METEORA_DLMM_ROUTEABLE_V1`, and the
routeable Raydium helper binds lower/active/upper `TickArray` accounts to
`MIMIR_ACCOUNTS_RAYDIUM_CLMM_ROUTEABLE_V1`.

`cpmmZeroFeeImmediateUnwindBounds` mirrors the on-chain/Kani-checked CPMM
manipulation-cost lower-bound helper for the current 10/50/100 bps profiles.
It uses bigint arithmetic with explicit u128 overflow checks and returns
`capitalRequiredUpQuote`, `capitalRequiredDownQuote`, `capitalRequiredFloor`,
and the current zero-fee immediate-unwind `economicLossFloor`.

`meteoraDlmmPriceFromIdX64` mirrors the on-chain Meteora active-bin Q64.64
price helper, including the bounded exponent domain and overflow behavior. Use
it to precompute or verify DLMM spot fixtures and source-plan assumptions.

### Meteora DLMM native TWAP (mixed kind 3): guarantees and limits

Kind 3 publishes a Q64 price derived from the Meteora DLMM program's own oracle. Mimir reads two observations of the pool's DLMM oracle, takes the mean active bin that the DLMM program charged between them, `m = (C_new − C_old) / (t_new − t_old)`, and applies Mimir's deterministic bin-to-price conversion, decimal normalization and, for V1 sources, the mint's current Token-2022 multiplier. Anyone can recompute the published price bit-for-bit from the kind-3 opening and the pool's configuration. The ring flags are `READY|AUTH` (3): the price is a point, not an interval.

A window is used only when all of the following hold:
- it is at least 240 s long (`W = t_new − t_old ≥ 240`);
- every observation in it was created at most 120 s after the previous observation's last update;
- every observation in it, including the one at `t_old`, was updated in place for less than 120 s;
- the newest update is at most 60 s old, and at most 128 observations are read;
- it starts after the pinned DLMM deployment second (`t_old > 1780470187`), and the refresh carries the pinned DLMM program generation: program `LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo`, ProgramData `HZcJwcJ2njPDxZtpPoKnF8v2w9QAx2rS7TdJPSRkbEhu`, deployment slot `423977638`.

**Conditional bound.** The bound below holds only if all of these premises hold for the pinned DLMM program. They are modelled from observed behaviour, not proven for the deployed binary; the generation pin identifies the binary but does not prove how it behaves.
1. Each oracle write adds (charged active bin) × (seconds since the previous write) to the cumulative, writes happen in chronological order, and nothing else (initialisation, resizing or any other instruction) changes an initialised observation.
2. Observation timestamps and Mimir's clock are the same cluster Unix clock.
3. The pool's `bin_step` does not change inside the window.
4. The charged bin is either the active bin just before the writing instruction moves it ("pre-swap") or just after ("post-swap"). Which of the two applies has not been established, so the bound is stated for both.

Let `μ` be the true time-weighted mean active bin over `(t_old, t_new]`. Under premises 1–4:

`|μ − m| ≤ (1/W)·Σ|G|·(t − w) ≤ (120/W)·Σ|G| ≤ Σ|G|/2`

The sum runs over active-bin changes `G`. Membership is decided by execution order, not by timestamps alone:
- Pre-swap: every change made by an instruction that does not write the oracle, executed after the last oracle write at `t_old` and before the first oracle write at `t_new`. A change in the same second as `t_new` that executes before that write is included; a change after it is not. `t` is the change's Unix time and `w` the time of the last oracle write before it.
- Post-swap: the changes above, plus the bin change made by each oracle-writing instruction that is the first write in its second within `(t_old, t_new]`; for these, `t − w` is the time since the previous such write.

Example (pre-swap): the active bin is 0; a swap that writes the oracle at `T+120` moves it to −10; an instruction that moves the bin without writing the oracle returns it to 0 at `T+240`, just before the final oracle write in that same second. The observations at `T`, `T+120` and `T+240` all have cumulative 0, so `m = 0`, while the true mean is `μ = −5`. The bound gives `10 × 120 / 240 = 5` bins, which is exact here. This window is accepted.

In price terms, with ideal arithmetic before Q64 rounding: `β^μ / β^m` lies in `[β^−δ, β^δ]`, where `β = 1 + bin_step/10000` and `δ = (1/W)·Σ|G|·(t − w)`. `β^μ` is the exponential of the true mean bin, i.e. the time-weighted geometric mean of the pool's bin price. It is not the arithmetic time-average price. For inverse orientation the sides swap.

**Not guaranteed:**
- Any absolute error limit. `Σ|G|` cannot be seen in the oracle, the pool or the current price. A move away and back between two oracle writes can leave every observation and the spot price unchanged while the true mean differs, for example by 5 bins (50.1 bps at bin_step 10) over 240 s.
- That the deployed DLMM program satisfies premises 1–4.
- The last ≤ 60 s after the newest oracle update, which is covered only by the freshness limit.
- Q64 conversion rounding.
- Token-2022 multiplier changes inside the window; the current multiplier is applied.
- `bin_step` changes inside the window (premise 3).

The ring confidence (10 bps floor) and the point flags `READY|AUTH` are not an error bound and do not describe an interval that contains the true price. If you need an absolute limit, use a source that provides one, or enforce your own bound on hidden moves.

Any upgrade of the DLMM program (a new ProgramData deployment slot) makes kind 3 unavailable, and refreshes that include it fail, until a reviewed Mimir release pins the new generation.

`squareQ64ToX64`, `normalizedDirectQ64PriceX64`,
`normalizedInverseQ64PriceX64`, and `normalizedCpmmPriceX64` mirror the
on-chain CLMM/CPMM price-normalization helpers, including u128 overflow checks,
decimal bounds, GCD reduction, and direct/inverse direction handling. Use them
to precompute Orca Whirlpool, Raydium CLMM, and CPMM spot fixtures without
drifting from the Pinocchio program's integer rounding.

The retired aggregate readiness manifests are not part of the npm surface.
Use the focused mainnet-capable evidence commands listed in `package.json`.

`npm run evidence:governance-actions` writes
`reports/governance-action-coverage-latest.json`. It computes deterministic
action hashes and PDA-bound action headers for all current governance action
target kinds: registry and policy. Feed-level lifecycle/status/update target
kinds were removed from the current SDK surface because finalized feeds are
immutable. The report pins create/approve instruction tags, data sizes,
account counts, approval mask, threshold, timing, action hash domains, and
aggregate governance action set hash
`76da651fff3cad8e34742be9ebca51ed59a92dbe8eda1a4e46dafef389c19e9b`. It also
mirrors the action lifecycle policy for thresholds `1..3`, second/third signer
approval, duplicate approval, expiry, revision mismatch, unsupported target
kinds, early effective slots, and late expiry. It uses no RPC, keypair,
signature, send, ProgramData extend, or deploy.

`npm run evidence:governance-lifecycle-execution-plan` writes
`reports/governance-lifecycle-execution-plan-latest.json`. It binds the checked
governance-action coverage report and writes the exact offline create/approve
plan for the current registry/policy target kinds: `CreateGovernanceAction` and
`ApproveGovernanceAction` steps, action PDAs, action hashes, tags `33/34`, data
sizes `193/41`, account counts `5/3`, expected approval masks, and required
future send gates. The execution-plan hash is
`f16bc44a08bfb194adc970d1ee707a26a5acc58762273411961e0f0aff55e919`. This
command emits an offline plan only; execution evidence is outside this package
command. It does not use RPC, load a keypair, sign, send, extend ProgramData,
deploy, or add any on-chain provider dependency.

`npm run evidence:routeable-depth` writes
`reports/routeable-depth-latest.json` from a deterministic adapter-neutral
range fixture. It hashes the built range evidence, evaluates the TierA depth
floors, records remaining traversal/admission gates, and uses no RPC, keypair,
signature, send, provider parser, or on-chain oracle dependency.

`npm run evidence:routeable-depth-adapters` writes
`reports/routeable-depth-adapter-fixtures-latest.json` with pinned offline
fixtures for Orca Whirlpool tick-array depth, Raydium CLMM tick-array depth,
and Meteora DLMM lower/active/upper bin-array depth. OpenBook-style book data
can still appear in support-only research reports, but it is not a v0.1
executable adapter. The report derives production-priority fixtures through
`buildRouteableDepthEvidenceFromDecodedLevels`, records per-fixture traversal
hashes, and writes traversal-set hash
`2aa9b6cbc1f637b961d89742e3abd9cbbb28ba41da08871f0ff5aaebaf72b3f2`.
It also exercises the read-only market-account acquisition helper through
mocked `getMultipleAccountsInfo` bundles, validates owner/executable/data-size
guards, records account counts `[8, 7, 7, 5]`, and writes account-bundle-set
hash `cf01425b1c58fb48dae4c43fbcdec57e442754784b7c08c07ee684f6a6f2551c`.
Fixture-set hashing still rejects duplicate fixture ids and duplicate non-null
account graph hashes so one upstream graph cannot be counted through multiple
fixture identities. The ordered coverage matrix, traversal/range binding,
account-bundle binding, and executable-adapter boundary are now checked by the
individual routeable-depth evidence scripts. Bounded Orca Whirlpool
lower/active/upper TickArray, Raydium CLMM lower/active/upper TickArray, and
Meteora lower/active/upper bin-array are executable. The checks fail closed unless the
configured minimum liquidity-age floor remains `64` slots and each fixture's
observed liquidity age stays above that floor. It uses no RPC, keypair,
signature, send, provider parser, or oracle dependency.

`npm run evidence:routeable-depth-live-acquisition` writes
`reports/routeable-depth-live-acquisition-latest.json`. By default it is an
offline plan-only report: it reads the checked adapter fixture report, derives
the live account request blueprint for each fixture id and role, binds
owner/data-size guards, records Orca/Raydium/Meteora as
`productionPriorityFixtureIds`, records OpenBook as `supportOnlyFixtureIds`,
binds the production-input template hash
`b2ff44fbacc4068f592707c06a48dcd1c4a709afae9c4097a9363030c7618720`, writes
acquisition hash `85de6250cede110b79282e9a0924c1746ed3dee88ea18a8dd1e3fadaa7eb7d1b`,
production-priority live-acquisition request hash
`99d804268fbd3a5fb5d04e286dec5e8666bb676c4aa85e12d511d6f935b07bbe`,
production-priority live-accounts config-template hash
`a3e0a4c47d4a4c20b4a852ad73bd28bd3053d5f944845b46d8be7deeadbb7469`,
and records `requiredProductionPriorityLiveAccountCount = 22`,
`requiredSupportOnlyLiveAccountCount = 5`, and
`productionPriorityLiveAccountAcquisitionComplete = false` until production-priority
live account config is supplied. Mainnet-target runs now fail closed unless
`MIMIR_ROUTEABLE_DEPTH_TARGET_PROGRAM_ID` is provided explicitly, and any live
RPC fetch must pass cluster genesis validation through
`MIMIR_ROUTEABLE_DEPTH_LIVE_RPC_URL`. The current checked mainnet target still
blocks on the missing
production-priority `source-config` role because the expected owner program
`By89yKDgx3aQCrb4vxW9Qirw6vrhhUQewWLumkWCmwUm` does not exist on mainnet. This
is read-only/offline evidence only: it never loads keypairs, signs, sends,
extends ProgramData, deploys, performs CPI, or adds an on-chain provider
dependency.

`npm run evidence:routeable-depth-production-calibration` writes
`reports/routeable-depth-production-calibration-latest.json`. It reads the
checked adapter fixture, production-input template, live-acquisition, and
manipulation-cost vector reports, then optionally validates per-fixture
production floors from
`MIMIR_ROUTEABLE_DEPTH_CALIBRATION_JSON`. The checked default deliberately
leaves `productionPriorityLiquidityCalibrationComplete = false`: calibration
hash
`a64c94c2ba73af45156f0966331c95be683eed42fb79edfe2641dc8ac907236e`,
production-priority calibration request hash
`3f5f1935ebd8efd38c4ab73ce3ddd42a68d10792d7eeb8a8d4988c5561f3afe8`,
production-priority calibration config-template hash
`a194d7b12cb3885a6d30c12d88c786b083255f842522a017e5f9949f10792a03`,
complete template binding, no production-priority live account acquisition, no
configured production floors, and
`productionPriorityLiquidityCalibrationComplete = false` until every
production-priority fixture has production liquidity-age, capital,
economic-loss, and observation-window inputs.
It uses no RPC, keypair, signature, send, ProgramData extend, deploy, CPI,
provider parser, or on-chain provider dependency.

`npm run evidence:routeable-depth-production-readiness` writes
`reports/routeable-depth-production-readiness-latest.json`. It reads the checked
adapter fixture, live-acquisition, and production-calibration reports, pins the
fixture-set/traversal/account-bundle/live-acquisition/calibration hashes,
verifies the required Orca/Raydium/Meteora production-priority fixture ids plus
the support-only OpenBook fixture and account counts, writes readiness hash
`01141c3be739e2e29703b3164853965bd0cd6a417ac5df3934e71fdd937b917b`, and records
`productionReady = false` until production-priority read-only live account
acquisition, production-priority min-liquidity-age and economic-loss-floor
calibration, and calibrated live routeable-depth evidence binding into TierA
admission are complete. Executable
on-chain routeable-depth adapter coverage is already complete at `3/3` active
adapters. OpenBook support remains
support-only and still requires live trade-flow proof, positive live turnover
proof, two-sided depth proof, liquidity-age calibration, and
manipulation-cost/economic-loss calibration before it can be treated as
production-priority. The
report records
Orca/Raydium/Meteora as production-priority fixture ids and OpenBook as
support-only until those five conditions all clear. The current checked target
already binds the explicit mainnet program id and real
Orca/Raydium/Meteora DEX role expectations, but `productionReady` remains false
because the expected `source-config` owner
program `By89yKDgx3aQCrb4vxW9Qirw6vrhhUQewWLumkWCmwUm` is absent on mainnet, so
the production-priority role set cannot be completed honestly. It
uses no RPC, keypair, signature, send, provider parser, CPI, or on-chain oracle
dependency.

`npm run evidence:anchor-policy` writes
`reports/anchor-policy-latest.json` for a native-only exception policy. It
recomputes `MIMIR_ANCHOR_POLICY_V1` and verifies the feed and native-exception
binding. It uses no RPC, keypair, signature, send, or CPI.

## Consumer limits

`max_recommended_notional` is advisory: a sizing hint derived from the capital a 50 bps move needs (scaled by the tier factor), not a bound on irrecoverable manipulation cost; VerifySnapshot accepts a requested notional up to it, so a value-bearing integrator must apply its own loss budget below it. `R_fee` (the published fee-loss floor) is monitoring-only. Neither is an admission minimum: feed admission and VerifySnapshot do not require a feed to reach either value.

## Verified Consumer Composition

`createMimirRefreshReadConsumerInstructions` builds the canonical client-side
sequence for integrating Mimir with another Solana program:

```ts
const instructions = createMimirRefreshReadConsumerInstructions({
  preReadInstructions: [fusedPublishIx], // tag 89
  snapshot,
  feedConfig,
  registry,
  sourcingPlan,
  policy: { ...policy, expectedSnapshotRevision },
  consumerInstruction,
});
```

The returned order is `preReadInstructions -> consumer`. The only accepted
classic pre-read is the immediately preceding fused publish (tag 89) over the
canonical snapshot/execution pair. `createMimirCompositeRefreshReadConsumerInstructions`
does the same for composites: the fused composite producer (tag 87), optionally
preceded by one tag-89 component publish. By default the helpers require an
exact snapshot revision, require the consumer instruction to read the verified
snapshot, and reject consumer instructions that write verified oracle accounts.
Do not set `RequireLiveTwapState`: on mainnet v1 VerifySnapshot always refuses
it, because the public TWAP account is never allocated.

VerifySnapshot (the generic reader) accepts `ATOMIC_LITE` (spot) snapshots. It
rejects `MIXED_BOUNDED`, `SAMPLED_INTERVAL` and `CURRENT_POINT` snapshots by
design; those are consumed through the in-transaction proof path.

## Mainnet v1 integrator notes

- Activation no longer allocates the public feed TWAP account, the public source
  rings or the CPMM public native proof. Their PDAs (`findFeedTwapPda`,
  `findSourceRingPda`, `findNativeTwapProofPda`, `SourcingPlan.twap_state`) stay
  reserved in the activation account list and remain empty System accounts.
  Live ring/TWAP state lives privately in the fused execution account.
- Legacy refreshers (`RefreshFeedTwapFromRingsAndSnapshot`, `RefreshSourceRingV1`,
  `CloseStaleProofOrBucketV1` tag 74) are refused on mainnet. Refresh through the
  fused producers (tag 89 classic, tag 87 composite).
- The generic reader accepts `ATOMIC_LITE` snapshots only; see above.
- Do not pass the reserved accounts to `ReclaimExcessRentV1` (tag 91).
- Same slot: a feed has at most one publication per slot. A later refresh in that
  slot re-observes: identical → Ok and nothing is written (revision unchanged, no
  refresh fee); any change of price, depth, status or condition → Custom 56; retry
  in the next slot.
- Composite creation: a transaction carries at most 64 account keys; a composite
  whose children are all new (e.g. 3 new children = 70 keys) cannot be created in
  one transaction, and `prepareCompositeFeed` still refuses it (never splits).
  `client.prepareCompositeFeedJourney(args, rpc)` is the explicit multi-transaction
  path: each missing child is its own atomic Classic activation, then the
  composite is created on the existing children. It is not atomic across
  transactions (created children stay usable if a later step stops) and does not
  promise one wallet prompt.
- Wallet-first signing: the wallet signs the unsigned reviewed wire first; the SDK
  admits only its exact fee/guard rewrite and wallet signature
  (`verifyMimirBetaWalletSignedTransactionV1`, or the no-sign
  `admitMimirBetaWalletSignedTransactionV1` / `admitMimirBetaWalletSignedBatchV1`),
  then the local asset signs those final bytes.
- `damm-onlyb-interval-v1` and `damm-reserve-interval-v3` require the DAMM v2 pool
  to hold permanently locked liquidity; the SDK refuses creation otherwise. Default
  DAMM v2 creation uses spot.
- V1 Classic creation (`prepareMimirV1ClassicCreation`, `@quantulabs/mimir-sdk/v1`)
  defaults every row, CPMM included, to `"spot"`. A SOL converter feed (the SOL/USDC feed a
  SOL-quoted feed converts through) must pass `recipes: ["native-bounded", ...]`
  explicitly; a spot SOL feed is not an admitted converter and the dependent
  creation fails closed.
- V1 (ABI-2) capability gate: `observeMimirV1Deployment` reads the deployed
  program (ProgramData, slot, ELF SHA-256); `verifyMimirAbi2Capability` checks a
  pinned `mimir-capability-manifest-v1-abi2` manifest against it, fail closed.
  ABI-1 manifests do not pass it, and V1 manifests do not pass `verifyMimirAbi1Capability`.
